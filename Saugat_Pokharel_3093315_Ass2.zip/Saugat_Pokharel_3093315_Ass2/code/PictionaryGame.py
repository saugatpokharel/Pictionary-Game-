#Saugat_Pokharel_3093315
#Assignment_02_HGP
#Griffith College Cork



#Necessary imports for the code(PyQt6 imports)
from PyQt6.QtWidgets import QApplication, QWidget, QMainWindow, QFileDialog, QDockWidget, QPushButton, QVBoxLayout, QLabel, QMessageBox
from PyQt6.QtGui import QIcon, QPainter, QPen, QAction, QPixmap
import sys
import csv, random
from PyQt6.QtCore import Qt, QPoint
from PyQt6.QtWidgets import QColorDialog
from PyQt6.QtWidgets import QSlider, QMenu
from PyQt6.QtWidgets import QColorDialog
from PyQt6.QtWidgets import QApplication, QMainWindow, QPushButton, QLabel, QMessageBox, QInputDialog, QFileDialog, QColorDialog


class PictionaryGame(QMainWindow):  # documentation https://doc.qt.io/qt-6/qwidget.html
    '''
    Painting Application class
    '''

    def __init__(self):
        super().__init__()

        # set window title
        self.setWindowTitle("Pictionary Game - Saugat_Pokharel_3093315")

        # set the windows dimensions
        top = 400
        left = 400
        width = 800
        height = 600
        self.setGeometry(top, left, width, height)
        self.gameover=False
        # set the icon
        # windows version
        self.setWindowIcon(
            QIcon("./icons/paint-brush.png"))  # documentation: https://doc.qt.io/qt-6/qwidget.html#windowIcon-prop
        
        # self.setWindowIcon(QIcon(QPixmap("./icons/paint-brush.png")))

        # image settings (default)
        self.image = QPixmap("./icons/canvas.png")  # documentation: https://doc.qt.io/qt-6/qpixmap.html
        self.image.fill(Qt.GlobalColor.white)  # documentation: https://doc.qt.io/qt-6/qpixmap.html#fill
        mainWidget = QWidget()
        mainWidget.setMaximumWidth(300)
 
        # draw settings (default)
        self.drawing = False
        self.brushSize = 3
        self.brushColor = Qt.GlobalColor.black  # documentation: https://doc.qt.io/qt-6/qt.html#GlobalColor-enum
        
      
        # Initialize scores and roles
        self.player1_score = 0
        self.player2_score = 0
        self.drawer = 1  # Player 1 starts as the drawer
        self.guesser = 2  # Player 2 is the guesser
        self.roundNumber = 1
        self.currentTurn = 1
        self.gameover = False
        self.mode = None


        # reference to last point recorded by mouse
        self.lastPoint = QPoint()  # documentation: https://doc.qt.io/qt-6/qpoint.html

        # set up menus
        mainMenu = self.menuBar()  # create a menu bar
        mainMenu.setNativeMenuBar(False)
        fileMenu = mainMenu.addMenu(" File")  # add the file menu to the menu bar, the space is required as "File" is reserved in Mac
        brushSizeMenu = mainMenu.addMenu(" Brush Size")  # add the "Brush Size" menu to the menu bar
        brushColorMenu = mainMenu.addMenu(" Brush Colour")  # add the "Brush Colour" menu to the menu bar
        editMenu = fileMenu.addMenu("Edit")
        



        # save menu item
        saveAction = QAction(QIcon("./icons/save.png"), "Save", self)  # create a save action with a png as an icon, documentation: https://doc.qt.io/qt-6/qaction.html
        saveAction.setShortcut("Ctrl+S")  # connect this save action to a keyboard shortcut, documentation: https://doc.qt.io/qt-6/qaction.html#shortcut-prop
        fileMenu.addAction(saveAction)  # add the save action to the file menu, documentation: https://doc.qt.io/qt-6/qwidget.html#addAction
        saveAction.triggered.connect(self.save)  # when the menu option is selected or the shortcut is used the save slot is triggered, documentation: https://doc.qt.io/qt-6/qaction.html#triggered

        #Open menu item(feature 1 )
        openAction = QAction(QIcon("./icons/open.png"), "Open", self)#create a open action in the user desktop
        openAction.setShortcut("Ctrl+O")# connect this open action to a keyboard shortcut
        fileMenu.addAction(openAction)#add the open action to the file menu
        openAction.triggered.connect(self.open)  # Use existing open function
        
        #Exit menu item(Feature 2)
        exitAction = QAction(QIcon("./icons/exit.png"), "Exit", self)#create a exit action to exit the application 
        exitAction.setShortcut("Ctrl+Q")#connect this exit action to a keyboard shortcut
        fileMenu.addAction(exitAction)#add the exit action to the file menu
        exitAction.triggered.connect(self.close)  # Use the built-in close method to exit the application

        # 2. Adding a new Help Menu==> new feature added-03
        helpMenu = mainMenu.addMenu(" Help")  # Add Help menu to the menu bar
        # Help Action
        helpAction = QAction("Help", self)#create a help action to get help to use the application
        helpAction.setShortcut("F1")# shortcut key implememtation
        helpMenu.addAction(helpAction)#add the  help actionn button
        helpAction.triggered.connect(self.showHelp)# triggered to connect with the data


        # About Action==> new feature added =04
        aboutAction = QAction("About", self)#create a About action to exit the application 
        aboutAction.setShortcut("F2")#connect this about action to a keyboard shortcut
        helpMenu.addAction(aboutAction)#add the about action to the ABout menu
        aboutAction.triggered.connect(self.showAbout)


        # clear
        clearAction = QAction(QIcon("./icons/clear.png"), "Clear", self)  # create a clear action with a png as an icon
        clearAction.setShortcut("Ctrl+C")  # connect this clear action to a keyboard shortcut
        fileMenu.addAction(clearAction)  # add this action to the file menu
        clearAction.triggered.connect(self.clear)  # when the menu option is selected or the shortcut is used the clear slot is triggered







        
        
        # brush thickness
        threepxAction = QAction(QIcon("./icons/threepx.png"), "3px", self)
        threepxAction.setShortcut("Ctrl+3")
        brushSizeMenu.addAction(threepxAction)  # connect the action to the function below
        threepxAction.triggered.connect(self.threepx)

        fivepxAction = QAction(QIcon("./icons/fivepx.png"), "5px", self)
        fivepxAction.setShortcut("Ctrl+5")
        brushSizeMenu.addAction(fivepxAction)
        fivepxAction.triggered.connect(self.fivepx)

        sevenpxAction = QAction(QIcon("./icons/sevenpx.png"), "7px", self)
        sevenpxAction.setShortcut("Ctrl+7")
        brushSizeMenu.addAction(sevenpxAction)
        sevenpxAction.triggered.connect(self.sevenpx)

        ninepxAction = QAction(QIcon("./icons/ninepx.png"), "9px", self)
        ninepxAction.setShortcut("Ctrl+9")
        brushSizeMenu.addAction(ninepxAction)
        ninepxAction.triggered.connect(self.ninepx)
        


        # Add this to the Brush Colour menu
        #feature added _05_user can select any color 
        colorPickerAction = QAction(QIcon("./icons/colors.png"),"Choose Color", self)#create a Color Picker action 
        colorPickerAction.setShortcut("Ctrl+P")#shorcut key
        brushColorMenu.addAction(colorPickerAction)
        colorPickerAction.triggered.connect(self.chooseColor)
        
        

        # brush colors
        blackAction = QAction(QIcon("./icons/black.png"), "Black", self)
        blackAction.setShortcut("Ctrl+B")
        brushColorMenu.addAction(blackAction);
        blackAction.triggered.connect(self.black)

        redAction = QAction(QIcon("./icons/red.png"), "Red", self)
        redAction.setShortcut("Ctrl+R")
        brushColorMenu.addAction(redAction);
        redAction.triggered.connect(self.red)

        greenAction = QAction(QIcon("./icons/green.png"), "Green", self)
        greenAction.setShortcut("Ctrl+G")
        brushColorMenu.addAction(greenAction);
        greenAction.triggered.connect(self.green)

        yellowAction = QAction(QIcon("./icons/yellow.png"), "Yellow", self)
        yellowAction.setShortcut("Ctrl+Y")
        brushColorMenu.addAction(yellowAction);
        yellowAction.triggered.connect(self.yellow)

        #undo and redo
        #feature added-06
        #History for unod and redo
        self.history = []
        self.history_index = -1

        # Undo menu item
        #feature added 07
        undoAction = QAction(QIcon("./icons/undo.png"), "Undo", self)
        undoAction.setShortcut("Ctrl+Z")
        editMenu.addAction(undoAction)
        undoAction.triggered.connect(self.undo)

        # Redo menu item
        redoAction = QAction(QIcon("./icons/redo.png"), "Redo", self)
        redoAction.setShortcut("Ctrl+Y")
        editMenu.addAction(redoAction)
        redoAction.triggered.connect(self.redo)

        # Eraser Implementation below
        # Eraser size
        self.eraserSize = 5  # Set an initial size for the eraser

        # Eraser action
        eraserAction = QAction(QIcon("./icons/eraser.png"), "Eraser", self)
        eraserAction.setShortcut("Ctrl+E")
        brushSizeMenu.addAction(eraserAction)
        eraserAction.triggered.connect(self.eraser)

        # Side Dock
        self.dockInfo = QDockWidget()
        self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, self.dockInfo)

        # widget inside the Dock
        playerInfo = QWidget()
        self.vbdock = QVBoxLayout()
        playerInfo.setLayout(self.vbdock)
        playerInfo.setMaximumSize(150, self.height())
        

        
        
        # Add score labels for Player 1 and Player 2
        
        self.player1_score_label = QLabel("Player 1: 0")  # Player 1 score label
        self.player2_score_label = QLabel("Player 2: 0")  # Player 2 score label
        self.vbdock.addWidget(self.player1_score_label)  # Add Player 1 score label to layout
        self.vbdock.addWidget(self.player2_score_label)  # Add Player 2 score label to layout
        self.vbdock.addSpacing(20)




        # Adding Brush Size Slider
        #feature added 08
        thicknessLabel = QLabel("Brush Size:", self)
        self.vbdock.addWidget(thicknessLabel)

        self.brushSlider = QSlider(Qt.Orientation.Horizontal, self)
        self.brushSlider.setMinimum(1)    # Minimum brush size
        self.brushSlider.setMaximum(30)   # Maximum brush size
        self.brushSlider.setValue(self.brushSize)  # Default value
        self.brushSlider.setTickInterval(1)  # Slider steps
        self.brushSlider.setTickPosition(QSlider.TickPosition.TicksBelow)
        self.brushSlider.valueChanged.connect(self.changeBrushSize)
        self.vbdock.addWidget(self.brushSlider)

        self.vbdock.addStretch(1)
        

         # Adding Start Game Button in the side dock
        self.startGameButton = QPushButton("Start Game")
        self.vbdock.addWidget(self.startGameButton)  # Add the Start Game button to the layout
        self.startGameButton.clicked.connect(self.startGame)


        # Make sure the button is added to a layout and the layout is set to the appropriate container
        self.skipTurnButton = QPushButton("Skip Turn")
        self.vbdock.addWidget(self.skipTurnButton)  # Add button to the layout

        # Connect the button's clicked signal to the skipTurn method
        self.skipTurnButton.clicked.connect(self.skipTurn)

        self.guessButton = QPushButton("Guess Word")
        self.vbdock.addWidget(self.guessButton)  # Add the Guess button to the layout
        self.guessButton.clicked.connect(self.onGuessClicked)



        # Add Reset button to the side dock
        self.resetButton = QPushButton("Reset")
        self.vbdock.addWidget(self.resetButton)  # Add Reset button to the layout
        self.resetButton.clicked.connect(self.onResetClicked)  # Connect Reset button to the handler

        # Setting colour of dock to gray
        playerInfo.setAutoFillBackground(True)
        p = playerInfo.palette()
        p.setColor(playerInfo.backgroundRole(), Qt.GlobalColor.gray)
        playerInfo.setPalette(p)

        # set widget for dock
        self.dockInfo.setWidget(playerInfo)
       
       
       
        self.getList("easy")
        self.currentWord = self.getWord()


    # event handlers
    def mousePressEvent(self, event):  # when the mouse is pressed, documentation: https://doc.qt.io/qt-6/qwidget.html#mousePressEvent
        if event.button() == Qt.MouseButton.LeftButton:  # if the pressed button is the left button
            self.drawing = True  # enter drawing mode
            self.lastPoint = event.pos()  # save the location of the mouse press as the lastPoint
            print(self.lastPoint)  # print the lastPoint for debugging purposes

    def mouseMoveEvent(self, event):  # when the mouse is moved, documenation: documentation: https://doc.qt.io/qt-6/qwidget.html#mouseMoveEvent
        if self.drawing:
            painter = QPainter(self.image)  # object which allows drawing to take place on an image
            # allows the selection of brush colour, brish size, line type, cap type, join type. Images available here http://doc.qt.io/qt-6/qpen.html
            painter.setPen(QPen(self.brushColor, self.brushSize, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
            painter.drawLine(self.lastPoint, event.pos())  # draw a line from the point of the orginal press to the point to where the mouse was dragged to
            self.lastPoint = event.pos()  # set the last point to refer to the point we have just moved to, this helps when drawing the next line segment
            self.update()  # call the update method of the widget which calls the paintEvent of this class
            self.update_history()

    def mouseReleaseEvent(self, event):  # when the mouse is released, documentation: https://doc.qt.io/qt-6/qwidget.html#mouseReleaseEvent
        if event.button() == Qt.MouseButton.LeftButton:  # if the released button is the left button, documentation: https://doc.qt.io/qt-6/qt.html#MouseButton-enum ,
            self.drawing = False  # exit drawing mode


     # Undo menu item
    def undo(self):
        if self.history_index > 0:
            self.history_index -= 1
            self.image = self.history[self.history_index].copy()
            self.update()

    # Redo menu item
    def redo(self):
        if self.history_index < len(self.history) - 1:
            self.history_index += 1
            self.image = self.history[self.history_index].copy()
            self.update() 

    def update_history(self):
        # Limit the history size to 10 for demonstration purposes
        self.history = self.history[:self.history_index + 1] + [self.image.copy()]
        self.history_index = len(self.history) - 1


     # Eraser Implementation
    def eraser(self):
        # Set the brush color to white for erasing
        self.brushColor = Qt.GlobalColor.white
        # Set the brush size to the eraser size
        self.brushSize = self.eraserSize
       
       

    # The updateEraserSize method is responsible for updating the eraser size based on the value of the eraser size slider.
    def updateEraserSize(self):
        # Update eraser size based on the slider value
        self.eraserSize = self.eraserSizeSlider.value()
        # If in eraser mode, update the brush size accordingly
        if self.brushColor == Qt.GlobalColor.white:
            self.brushSize = self.eraserSize

    # When the eraser tool is selected, it sets the brush color to white (Qt.GlobalColor.white) and adjusts the brush size to the specified eraser size.
    def setupEraserMenu(self):
        eraserMenu = QMenu(self)

        # Eraser action
        eraserAction = QAction(QIcon("./icons/eraser.png"), "Eraser", self)
        eraserAction.setShortcut("Ctrl+E")
        eraserMenu.addAction(eraserAction)
        eraserAction.triggered.connect(self.showEraserSlider)

        # Eraser size slider
        self.eraserSizeSlider = QSlider(Qt.Orientation.Horizontal)
        self.eraserSizeSlider.setMinimum(1)
        self.eraserSizeSlider.setMaximum(20)
        self.eraserSizeSlider.setValue(self.eraserSize)
        self.eraserSizeSlider.setTickPosition(QSlider.TickPosition.TicksBelow)
        self.eraserSizeSlider.setTickInterval(1)
        self.eraserSizeSlider.valueChanged.connect(self.updateEraserSize)

        # Add eraser size slider to layout
        self.vbdock.addWidget(self.eraserSizeSlider)

        return eraserMenu
     
    def showEraserSlider(self):
        # Show the eraser size slider
        self.eraserSizeSlider.show()



    def startGame(self):
        
        # Set up role labels
        self.drawer_label = QLabel("Drawer: Player 1")
        self.guesser_label = QLabel("Guesser: Player 2")
        self.vbdock.addWidget(self.drawer_label)
        self.vbdock.addWidget(self.guesser_label)

        # Ask for difficulty mode selection
        mode, ok = QInputDialog.getItem(
        self, "Select Difficulty", "Choose difficulty:", ["Easy", "Hard"], 0, False
        )
        if ok and mode:
            self.mode = mode.lower()  # "easy" or "hard"
            self.getList(self.mode)  # Load words based on mode

        # Update initial scores
        self.updateScores(self.player1_score, self.player2_score)

        

        # Check if maximum rounds reached
        if self.roundNumber > 5:
            self.checkGameOver()
        else:
            self.nextTurn()



    def checkGuess(self, guess):
        """Check if the current guess is correct and update the score."""
        if guess.lower() == self.random_word.lower():
            if self.guesser == 1:
                self.player1_score += 1
            else:
                self.player2_score += 1
            QMessageBox.information(self, "Correct!", "Correct Guess!")
        else:
            QMessageBox.warning(self, "Incorrect", "Wrong Guess!")
    
        # Proceed to the next turn
        self.nextTurn()

    def getList(self, mode):
        """Load words from the specified mode file."""
        file_name = f"{mode}mode.txt"
        try:
            with open(file_name, 'r') as file:
                self.wordList = [word.strip() for word in file.readlines()]
        except FileNotFoundError:
            QMessageBox.critical(self, "Error", f"File {file_name} not found!")
        self.wordList = []

    '''def getWord(self):
        """Select a random word from the loaded word list."""
        if self.wordList:
            return random.choice(self.wordList)
        return None'''

    def showRandomWordForDrawer(self):
        """Show the random word to the drawer using a QMessageBox."""
        self.random_word = self.getWord()
        if self.random_word:
            QMessageBox.information(
            self, "Letsss Gooo", f"\n Don't show to your Opponent!!\n Your word to draw is: {self.random_word} "
        )


    def onGuessClicked(self):
        if self.gameover:
            return  # If the game is over, do nothing

        # Prompt Player 2 for their guess
        guess, ok = QInputDialog.getText(self, "Enter Guess", "What is your guess?")
    
        if ok and guess:
            # Check if the guess is correct
            self.checkGuess(guess)



    def showWinner(self, player):
        """ Show the winner at the end of the game """
        QMessageBox.information(self, "Game Over", f"Player {player} wins!")
        self.gameover = True


    def skipTurn(self):
        """ Skip the current turn and move to the next round """
        if self.gameover:
            return  # No action if the game is over
    
        self.nextTurn() 


    


    

    def checkGuess(self, guess):
        """Check if the guess is correct."""
        if guess.lower() == self.random_word.lower():
            if self.guesser == 1:
                self.player1_score += 1
            else:
                self.player2_score += 1

            # Player 2 is the drawer, so they get 2 points for a correct guess
        if self.drawer == 2:  # Player 2 is the drawer
            self.player2_score += 2  # Player 2 gets an extra point for being the drawer

            QMessageBox.information(self, "Correct!", "Correct Guess!")
        else:
            QMessageBox.warning(self, "Incorrect", "Wrong Guess!")

        self.nextTurn()



    def nextTurn(self):

        # Check if maximum rounds reached
        if self.roundNumber > 5:
            self.checkGameOver()
            return
        
        # Switch roles between drawer and guesser
        self.drawer, self.guesser = self.guesser, self.drawer
        self.currentTurn += 1

        # Update role labels
        self.drawer_label.setText(f"Drawer: Player {self.drawer}")
        self.guesser_label.setText(f"Guesser: Player {self.guesser}")

        # Show the new word for the current drawer
        self.showRandomWordForDrawer()
        self.updateScores(self.player1_score, self.player2_score)

        # Increment round number
        self.roundNumber += 1

    #GameOver if the player gets point 5
    def checkGameOver(self):
        """ Check if the game is over and declare a winner """
        if self.player1_score >= 5:
            self.showWinner(1)
        elif self.player2_score >= 5:
            self.showWinner(2)



    def onResetClicked(self):
        """Reset the game to start a new round."""
        self.gameover = False
        self.roundNumber = 1  # Start the round from 1
        self.player1_score = 0  # Reset Player 1 score
        self.player2_score = 0  # Reset Player 2 score

        # Reset player roles
        self.drawer = 1  # Player 1 starts as the drawer
        self.guesser = 2  # Player 2 starts as the guesser

        # Reset UI elements
        self.drawer_label.setText(f"Drawer: Player {self.drawer}")
        self.guesser_label.setText(f"Guesser: Player {self.guesser}")
        self.updateScores(self.player1_score, self.player2_score)

    def clearDrawing(self):
        """Clear the drawing canvas."""
        

        # Optional: Clear any previously drawn word
        self.clearDrawing()

        # Start a new game with fresh state
        self.showRandomWordForDrawer()  # Show the word for the new drawer
        self.gameover = False  # Ensure the game is not over
        QMessageBox.information(self, "Game Reset", "The game has been reset. Let’s play again!")





    # paint events
    def paintEvent(self, event):
       
        canvasPainter = QPainter(self)  # create a new QPainter object, documentation: https://doc.qt.io/qt-6/qpainter.html
        canvasPainter.drawPixmap(QPoint(), self.image)  # draw the image , documentation: https://doc.qt.io/qt-6/qpainter.html#drawImage-1

    # resize event - this function is called
    def resizeEvent(self, event):
        self.image = self.image.scaled(self.width(), self.height())

    # slots
    def save(self):
        filePath, _ = QFileDialog.getSaveFileName(self, "Save Image", "",
                                                  "PNG(*.png);;JPG(*.jpg *.jpeg);;All Files (*.*)")
        if filePath == "":  # if the file path is empty
            return  # do nothing and return
        self.image.save(filePath)  # save file image to the file path

    def clear(self):
        self.image.fill(
            Qt.GlobalColor.white)  # fill the image with white, documentation: https://doc.qt.io/qt-6/qimage.html#fill-2
        self.update_history()  # call the update method of the widget which calls the paintEvent of this class

    def threepx(self):  # the brush size is set to 3
        self.brushSize = 3

    def fivepx(self):
        self.brushSize = 5

    def sevenpx(self):
        self.brushSize = 7

    def ninepx(self):
        self.brushSize = 9

    def black(self):  # the brush color is set to black
        self.brushColor = Qt.GlobalColor.black


    def red(self):
        self.brushColor = Qt.GlobalColor.red

    def green(self):
        self.brushColor = Qt.GlobalColor.green

    def yellow(self):
        self.brushColor = Qt.GlobalColor.yellow

    
    
    def changeBrushSize(self, value):
        self.brushSize = value


    def chooseColor(self):
     color = QColorDialog.getColor()  # Open color picker dialog
     if color.isValid():  # Check if a valid color was selected
        self.brushColor = color  # Set the chosen color as the brush color
        

    # Update the player scores dynamically:
    def updateScores(self, player1_score, player2_score):
        self.player1_score_label.setText(f"Player 1: {player1_score}")
        self.player2_score_label.setText(f"Player 2: {player2_score}")
    



    # Helper method to show About dialog
    def showAbout(self):
        QMessageBox.information(self, "About Pictionary Game", 
                            "Pictionary Game v3.33\nCreated using PyQt6\nA simple drawing and guessing game.\n Created By Saugat_Pokharel\n Student ID= 3093315\n Griffith College Cork\n\n This game represents as a Pictionary Game!")

    # Helper method to show Help dialog
    def showHelp(self):
        QMessageBox.information(self, "Help", 
                            "Instructions:\n"
                            "- Use the brush to draw the given word.\n"
                            "- Player 1 tries to guess the word at first.\n"
                            "- Use 'Start Game' button to begin.\n"
                            "- Use 'Skip Turn' to skip a word.\n"
                            "- Save your drawings using the File menu.\n"
                            "Have Fun!")







    #Get a random word from the list read from file
    def getWord(self):
        randomWord = random.choice(self.wordList)
        print(randomWord)
        return randomWord

    #read word list from file
    def getList(self, mode):
        with open(mode + 'mode.txt') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            line_count = 0
            for row in csv_reader:
                #print(row)
                self.wordList = row
                line_count += 1
            #print(f'Processed {line_count} lines.')

    # open a file
    def open(self):
        
       
        filePath, _ = QFileDialog.getOpenFileName(self, "Open Image", "",
                                                  "PNG(*.png);;JPG(*.jpg *.jpeg);;All Files (*.*)")
        if filePath == "":  # if not file is selected exit
            return
        with open(filePath, 'rb') as f:  # open the file in binary mode for reading
            content = f.read()  # read the file
        self.image.loadFromData(content)  # load the data into the file
        width = self.width()  # get the width of the current QImage in your application
        height = self.height()  # get the height of the current QImage in your application
        self.image = self.image.scaled(width, height)  # scale the image from file and put it in your QImage
        self.update()  # call the update method of the widget which calls the paintEvent of this class


#  will be executed if it is the main module but not if the module is imported
#  https://stackoverflow.com/questions/419163/what-does-if-name-main-do
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = PictionaryGame()
    window.show()
    app.exec()  # start the event loop running

